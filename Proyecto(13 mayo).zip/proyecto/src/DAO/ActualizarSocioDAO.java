package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ActualizarSocioDAO {

	public static boolean actualizarSocio(String dni) {

		try {

			Connection con = Conexion.obtenerConexion();

			String sql = "UPDATE socio SET dni_usuario = ? WHERE dni_usuario = ?";
			
			PreparedStatement ps = con.prepareStatement(sql);

			ps.setString(8, dni);

			int filasAfectadas = ps.executeUpdate();

			ps.close();
			con.close();

			return filasAfectadas > 0;

		} catch (Exception e) {

			e.printStackTrace();
			return false;
		}
	}
}