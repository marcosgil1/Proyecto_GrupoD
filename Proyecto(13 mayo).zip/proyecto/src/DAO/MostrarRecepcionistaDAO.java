package DAO;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class MostrarRecepcionistaDAO {

	public static Object[][] obtenerRecepcionista() {

		ArrayList<Object[]> lista = new ArrayList<>();

		 String sql =
		            "SELECT u.dni, u.nombre, u.apellidos, u.telefono, " +
		            "u.email, u.fecha_alta, u.estado, u.contrasena " +
		            "FROM usuario u " +
		            "INNER JOIN recepcionista r ON u.dni = r.dni_usuario";

		try (Connection con = Conexion.obtenerConexion();
				Statement sta = con.createStatement();
				ResultSet rs = sta.executeQuery(sql)) {

			while (rs.next()) {

				Object[] fila = new Object[] {
	                    rs.getString("dni"),
	                    rs.getString("nombre"),
	                    rs.getString("apellidos"),
	                    rs.getString("telefono"),
	                    rs.getString("email"),
	                    rs.getDate("fecha_alta"),
	                    rs.getString("estado"),
	                    rs.getString("contrasena")
	                };

	                lista.add(fila);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return lista.toArray(new Object[0][]);
	}
}