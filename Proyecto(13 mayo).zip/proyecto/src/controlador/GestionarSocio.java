package controlador;

import DAO.*;
import clases.*;

public class GestionarSocio {
	
	// Socio FULL
	public static boolean insertarSocioFull(SocioFull s) {
		return InsertarUsuarioDAO.insertarSocioFull(s);
	}
	
	// Socio Flexible
	public static boolean insertarSocioFlexible(SocioFlexible s) {
		return InsertarUsuarioDAO.insertarSocioFlexible(s);
	}
	
	public static boolean eliminarSocio(Socio s) {
		return EliminarUsuarioDAO.eliminarUsuarioBD(s);
	}
	
	public static Object[][] mostrarSocio() {
		return MostrarSociosDAO.obtenerSocios();
	}

	public static boolean actualizarSocio(String dni) {
		return ActualizarSocioDAO.actualizarSocio(dni);
	}
}