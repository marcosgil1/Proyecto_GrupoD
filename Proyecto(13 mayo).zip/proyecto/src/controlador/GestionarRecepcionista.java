package controlador;

import java.awt.event.MouseEvent;

import DAO.*;
import clases.*;

public class GestionarRecepcionista {
	
	// Socio FULL
	public static boolean insertarSocioFull(SocioFull s) {
		return InsertarUsuarioDAO.insertarSocioFull(s);
	}
	
	// Socio Flexible
	public static boolean insertarSocioFlexible(SocioFlexible s) {
		return InsertarUsuarioDAO.insertarSocioFlexible(s);
	}
	
	// Entrenador
	public static boolean insertarEntrenador(Entrenador e) {
		return InsertarUsuarioDAO.insertarEntrenador(e);
	}
	
	// Administrador
	public static boolean insertarAdministrador(Administrador a) {
		return InsertarUsuarioDAO.insertarUsuarioBasico(a, "Administrador");
	}
	
	// Recepcionista
	public static boolean insertarRecepcionista(Recepcionista r) {
		return InsertarUsuarioDAO.insertarUsuarioBasico(r, "Recepcionista");
	}

	public static boolean eliminarRecepcionista(Recepcionista r) {
		return EliminarUsuarioDAO.eliminarUsuarioBD(r);
	}
	
	public static Object[][] mostrarRecepcionista() {
		return MostrarRecepcionistaDAO.obtenerRecepcionista();
	}

	public static boolean actualizarUsuario(String dni, String nombre, String apellidos, String telefono, String email,
			String fechaAlta, String estado, String contrasena) {
		return ActualizarUsuarioDAO.actualizarUsuario(dni, nombre, apellidos, telefono, email, fechaAlta, estado, contrasena);
	}

	

}