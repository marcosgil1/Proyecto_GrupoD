package GUI;

import javax.swing.*;

import controlador.GestionarSocio;
import controlador.GestionarUsuario;

import java.awt.*;

public class ActualizarSocioGUI extends JFrame {

	private JTextField txtDni;

	public ActualizarSocioGUI(String dni) {

		setTitle("Actualizar Usuario");
		setSize(400, 500);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setLayout(new GridLayout(10, 2));

		txtDni = new JTextField(dni);
		txtDni.setEditable(false); // El DNI no se puede modificar

		add(new JLabel("DNI"));
		add(txtDni);


		JButton btnGuardar = new JButton("Guardar cambios");
		btnGuardar.addActionListener(e -> actualizarSocio());

		JButton btnVolver = new JButton("Volver");
		btnVolver.addActionListener(e -> dispose());

		add(btnGuardar);
		add(btnVolver);

		setVisible(true);
	}

	private void actualizarSocio() {

		String dni = txtDni.getText();

		boolean actualizado = GestionarSocio.actualizarSocio(dni);
		
		if(actualizado) {
			JOptionPane.showMessageDialog(null, "Usuario actualizado correctamente");
			dispose(); // Cerrar la ventana después de actualizar
		} else {
			JOptionPane.showMessageDialog(null, "Error: No se pudo actualizar el usuario");
		}
	}
}