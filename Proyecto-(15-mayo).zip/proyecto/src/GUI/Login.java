package GUI;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel contentPane;
	private JTextField textUsuario;
	private JPasswordField textContrasena;

	public static void main(String[] args) {
		EventQueue.invokeLater(() -> {
			try {
				Login frame = new Login();
				frame.setVisible(true);
			} catch (Exception e) {
				e.printStackTrace();
			}
		});
	}

	public Login() {

		// Configuración ventana
		setTitle("Inicio de Sesión");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(450, 320);
		setLocationRelativeTo(null);
		setResizable(false);

		// Panel principal
		contentPane = new JPanel();
		contentPane.setLayout(null);
		contentPane.setBackground(new Color(245, 245, 245));
		contentPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		setContentPane(contentPane);

		// Título
		JLabel lblTitulo = new JLabel("INICIO DE SESIÓN");
		lblTitulo.setFont(new Font("Arial", Font.BOLD, 24));
		lblTitulo.setBounds(105, 30, 250, 30);
		contentPane.add(lblTitulo);

		// Usuario
		JLabel lblUsuario = new JLabel("Usuario");
		lblUsuario.setFont(new Font("Arial", Font.PLAIN, 14));
		lblUsuario.setBounds(90, 90, 100, 20);
		contentPane.add(lblUsuario);

		textUsuario = new JTextField();
		textUsuario.setBounds(90, 115, 250, 30);
		textUsuario.setFont(new Font("Arial", Font.PLAIN, 14));
		contentPane.add(textUsuario);

		// Contraseña
		JLabel lblContrasena = new JLabel("Contraseña");
		lblContrasena.setFont(new Font("Arial", Font.PLAIN, 14));
		lblContrasena.setBounds(90, 155, 100, 20);
		contentPane.add(lblContrasena);

		textContrasena = new JPasswordField();
		textContrasena.setBounds(90, 180, 250, 30);
		textContrasena.setFont(new Font("Arial", Font.PLAIN, 14));
		contentPane.add(textContrasena);

		// Botón iniciar sesión
		JButton btnIniciarSesion = new JButton("Iniciar Sesión");
		btnIniciarSesion.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		btnIniciarSesion.setFont(new Font("Arial", Font.BOLD, 14));
		btnIniciarSesion.setBounds(135, 230, 160, 35);
		contentPane.add(btnIniciarSesion);
	}
}