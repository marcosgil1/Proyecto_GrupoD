package GUI;

import javax.swing.*;
import controlador.GestionarActividadProgramada;
import clases.ActividadProgramada;
import java.awt.*;

public class ActividadProgramadaActualizarGUI extends JDialog {
    private JComboBox<String> comboActividad;
    private JTextField txtFechaInicio;
    private JTextField txtFechaFin;
    private JComboBox<String> comboEntrenador;
    private JComboBox<String> comboSala;
    private ActividadProgramada actividadProgramada;
    private Runnable onProgramacionActualizada;
    
    public ActividadProgramadaActualizarGUI(ActividadProgramada actividadProgramada, Runnable onProgramacionActualizada) {
        super((JFrame) null, "Editar Actividad Programada", true);
        this.actividadProgramada = actividadProgramada;
        this.onProgramacionActualizada = onProgramacionActualizada;
        iniciarComponentes();
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    private void iniciarComponentes() {
        setLayout(new GridLayout(6, 2, 10, 10));
        
        // ComboBox de Actividades
        Object[][] actividades = GestionarActividadProgramada.obtenerActividadesParaCombo();
        comboActividad = new JComboBox<>();
        int actIndex = 0;
        for (int i = 0; i < actividades.length; i++) {
            comboActividad.addItem(actividades[i][0] + " - " + actividades[i][1]);
            if (Integer.parseInt(actividades[i][0].toString()) == actividadProgramada.getIdActividad()) {
                actIndex = i;
            }
        }
        comboActividad.setSelectedIndex(actIndex);
        comboActividad.setEnabled(false); // No se puede cambiar la actividad en edición
        
        // Fechas
        txtFechaInicio = new JTextField(actividadProgramada.getFechaInicio(), 20);
        txtFechaInicio.setEnabled(false); // No se puede cambiar la fecha inicio (es parte de la PK)
        txtFechaFin = new JTextField(actividadProgramada.getFechaFin(), 20);
        
        // ComboBox de Entrenadores
        Object[][] entrenadores = GestionarActividadProgramada.obtenerEntrenadoresParaCombo();
        comboEntrenador = new JComboBox<>();
        int entIndex = 0;
        for (int i = 0; i < entrenadores.length; i++) {
            comboEntrenador.addItem(entrenadores[i][0] + " - " + entrenadores[i][1]);
            if (entrenadores[i][0].toString().equals(actividadProgramada.getDniEntrenador())) {
                entIndex = i;
            }
        }
        comboEntrenador.setSelectedIndex(entIndex);
        
        // ComboBox de Salas
        Object[][] salas = GestionarActividadProgramada.obtenerSalasParaCombo();
        comboSala = new JComboBox<>();
        int salaIndex = 0;
        for (int i = 0; i < salas.length; i++) {
            comboSala.addItem(salas[i][0] + " - " + salas[i][1]);
            if (Integer.parseInt(salas[i][0].toString()) == actividadProgramada.getIdSala()) {
                salaIndex = i;
            }
        }
        comboSala.setSelectedIndex(salaIndex);
        
      
        add(new JLabel("Actividad:"));
        add(comboActividad);
        
        add(new JLabel("Fecha Inicio:"));
        add(txtFechaInicio);
        
        add(new JLabel("Fecha Fin:"));
        add(txtFechaFin);
        
        add(new JLabel("Entrenador:"));
        add(comboEntrenador);
        
        add(new JLabel("Sala:"));
        add(comboSala);
        
        // Botones
        JButton btnAceptar = new JButton("Aceptar");
        JButton btnCancelar = new JButton("Cancelar");
        
        btnAceptar.addActionListener(e -> {
            if (actualizarProgramacion()) {
                dispose();
            }
        });
        
        btnCancelar.addActionListener(e -> dispose());
        
        add(btnAceptar);
        add(btnCancelar);
        
        setSize(550, 350);
        setResizable(false);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }
    
    private boolean actualizarProgramacion() {
        try {
            String fechaFin = txtFechaFin.getText().trim();
            String fechaInicio = actividadProgramada.getFechaInicio();
            
            // Validar que fecha_fin sea mayor que fecha_inicio
            if (fechaFin.compareTo(fechaInicio) <= 0) {
                JOptionPane.showMessageDialog(this, "La fecha fin debe ser mayor que la fecha inicio", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
            // Obtener DNI del entrenador
            String entSeleccionado = (String) comboEntrenador.getSelectedItem();
            String dniEntrenador = entSeleccionado.split(" - ")[0];
            
            // Obtener ID de la sala
            String salaSeleccionada = (String) comboSala.getSelectedItem();
            int idSala = Integer.parseInt(salaSeleccionada.split(" - ")[0]);
            
            actividadProgramada.setFechaFin(fechaFin);
            actividadProgramada.setDniEntrenador(dniEntrenador);
            actividadProgramada.setIdSala(idSala);
            
            boolean actualizado = GestionarActividadProgramada.actualizarActividadProgramada(actividadProgramada);
            
            if (actualizado) {
                JOptionPane.showMessageDialog(this, "Programación actualizada correctamente", 
                                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                if (onProgramacionActualizada != null) {
                    onProgramacionActualizada.run();
                }
                return true;
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar la programación", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error en los datos ingresados", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}