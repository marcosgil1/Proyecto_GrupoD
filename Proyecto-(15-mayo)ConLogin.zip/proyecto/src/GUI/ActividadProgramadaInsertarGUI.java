package GUI;

import javax.swing.*;
import controlador.GestionarActividadProgramada;
import clases.ActividadProgramada;
import java.awt.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ActividadProgramadaInsertarGUI extends JDialog {
    private JComboBox<String> comboActividad;
    private JTextField txtFechaInicio;
    private JTextField txtFechaFin;
    private JComboBox<String> comboEntrenador;
    private JComboBox<String> comboSala;
    private Runnable onProgramacionCreada;
    
    public ActividadProgramadaInsertarGUI(JFrame parent, Runnable onProgramacionCreada) {
        super(parent, "Nueva Actividad Programada", true);
        this.onProgramacionCreada = onProgramacionCreada;
        iniciarComponentes();
        setLocationRelativeTo(parent);
        setVisible(true);
    }
    
    private void iniciarComponentes() {
        setLayout(new GridLayout(6, 2, 10, 10));
        
        // ComboBox de Actividades
        Object[][] actividades = GestionarActividadProgramada.obtenerActividadesParaCombo();
        comboActividad = new JComboBox<>();
        for (Object[] act : actividades) {
            comboActividad.addItem(act[0] + " - " + act[1]);
        }
        
        // Fechas
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        txtFechaInicio = new JTextField(LocalDateTime.now().format(formatter), 20);
        txtFechaFin = new JTextField(LocalDateTime.now().plusHours(1).format(formatter), 20);
        
        // ComboBox de Entrenadores
        Object[][] entrenadores = GestionarActividadProgramada.obtenerEntrenadoresParaCombo();
        comboEntrenador = new JComboBox<>();
        for (Object[] ent : entrenadores) {
            comboEntrenador.addItem(ent[0] + " - " + ent[1]);
        }
        
        // ComboBox de Salas
        Object[][] salas = GestionarActividadProgramada.obtenerSalasParaCombo();
        comboSala = new JComboBox<>();
        for (Object[] sala : salas) {
            comboSala.addItem(sala[0] + " - " + sala[1]);
        }
        
        // Añadir componentes al GridLayout
        add(new JLabel("Actividad:"));
        add(comboActividad);
        
        add(new JLabel("Fecha Inicio (YYYY-MM-DD HH:MM:SS):"));
        add(txtFechaInicio);
        
        add(new JLabel("Fecha Fin (YYYY-MM-DD HH:MM:SS):"));
        add(txtFechaFin);
        
        add(new JLabel("Entrenador:"));
        add(comboEntrenador);
        
        add(new JLabel("Sala:"));
        add(comboSala);
        
        // Botones
        JButton btnAceptar = new JButton("Aceptar");
        JButton btnCancelar = new JButton("Cancelar");
        
        btnAceptar.addActionListener(e -> {
            if (guardarProgramacion()) {
                dispose();
            }
        });
        
        btnCancelar.addActionListener(e -> dispose());
        
        add(btnAceptar);
        add(btnCancelar);
        
        setSize(550, 350);
        setResizable(false);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }
    
    private boolean guardarProgramacion() {
        try {
            // Obtener ID de la actividad seleccionada
            String actSeleccionada = (String) comboActividad.getSelectedItem();
            int idActividad = Integer.parseInt(actSeleccionada.split(" - ")[0]);
            
            String fechaInicio = txtFechaInicio.getText().trim();
            String fechaFin = txtFechaFin.getText().trim();
            
            // Validar que fecha_fin sea mayor que fecha_inicio
            if (fechaFin.compareTo(fechaInicio) <= 0) {
                JOptionPane.showMessageDialog(this, "La fecha fin debe ser mayor que la fecha inicio", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
            // Obtener DNI del entrenador
            String entSeleccionado = (String) comboEntrenador.getSelectedItem();
            String dniEntrenador = entSeleccionado.split(" - ")[0];
            
            // Obtener ID de la sala
            String salaSeleccionada = (String) comboSala.getSelectedItem();
            int idSala = Integer.parseInt(salaSeleccionada.split(" - ")[0]);
            
            ActividadProgramada nueva = new ActividadProgramada(idActividad, fechaInicio, fechaFin, dniEntrenador, idSala);
            boolean insertado = GestionarActividadProgramada.insertarActividadProgramada(nueva);
            
            if (insertado) {
                JOptionPane.showMessageDialog(this, "Actividad programada correctamente", 
                                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                if (onProgramacionCreada != null) {
                    onProgramacionCreada.run();
                }
                return true;
            } else {
                JOptionPane.showMessageDialog(this, "Error al programar la actividad", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error en los datos ingresados: " + ex.getMessage(), 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}