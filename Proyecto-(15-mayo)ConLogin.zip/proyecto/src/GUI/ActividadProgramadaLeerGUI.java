package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import controlador.GestionarActividadProgramada;
import clases.ActividadProgramada;

public class ActividadProgramadaLeerGUI extends JFrame {

    private JTable tabla;
    private DefaultTableModel modelo;

    public ActividadProgramadaLeerGUI() {
        setTitle("Gestión de Actividades Programadas");
        setSize(1100, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        iniciarTabla();
        cargarActividadesProgramadas();
        
        setVisible(true);
    }

    private void iniciarTabla() {
        modelo = new DefaultTableModel();
        
        modelo.addColumn("ID Actividad");
        modelo.addColumn("Actividad");
        modelo.addColumn("Fecha Inicio");
        modelo.addColumn("Fecha Fin");
        modelo.addColumn("Entrenador");
        modelo.addColumn("Sala");
        modelo.addColumn("Modificar");
        modelo.addColumn("Eliminar");
        
        tabla = new JTable(modelo);
        
        tabla.getColumnModel().getColumn(6).setPreferredWidth(100);
        tabla.getColumnModel().getColumn(7).setPreferredWidth(100);
        
        tabla.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila = tabla.rowAtPoint(e.getPoint());
                int columna = tabla.columnAtPoint(e.getPoint());
                
                if (columna == 6) { // Botón Modificar
                    int idActividad = Integer.parseInt(tabla.getValueAt(fila, 0).toString());
                    String fechaInicio = tabla.getValueAt(fila, 2).toString();
                    
                    ActividadProgramada ap = GestionarActividadProgramada.obtenerActividadProgramada(idActividad, fechaInicio);
                    new ActividadProgramadaActualizarGUI(ap, () -> cargarActividadesProgramadas());
                    
                } else if (columna == 7) { // Botón Eliminar
                    int idActividad = Integer.parseInt(tabla.getValueAt(fila, 0).toString());
                    String fechaInicio = tabla.getValueAt(fila, 2).toString();
                    String nombreActividad = tabla.getValueAt(fila, 1).toString();
                    
                    int confirm = JOptionPane.showConfirmDialog(null,
                            "¿Estás seguro de que quieres eliminar la programación de: " + nombreActividad + " del " + fechaInicio + "?",
                            "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        boolean eliminado = GestionarActividadProgramada.eliminarActividadProgramada(idActividad, fechaInicio);
                        
                        if (eliminado) {
                            JOptionPane.showMessageDialog(null, "Programación eliminada correctamente");
                            cargarActividadesProgramadas();
                        } else {
                            JOptionPane.showMessageDialog(null, "Error al eliminar la programación");
                        }
                    }
                }
            }
        });
        
        JScrollPane scroll = new JScrollPane(tabla);
        
        // Botones
        JButton btnNuevo = new JButton("+ Nueva Programación");
        btnNuevo.addActionListener(e -> new ActividadProgramadaInsertarGUI(this, () -> cargarActividadesProgramadas()));
        
        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.addActionListener(e -> cargarActividadesProgramadas());
        
        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(e -> dispose());
        
        JPanel panelSuperior = new JPanel();
        panelSuperior.add(btnNuevo);
        panelSuperior.add(btnActualizar);
        panelSuperior.add(btnVolver);
        
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panelSuperior, BorderLayout.NORTH);
        getContentPane().add(scroll, BorderLayout.CENTER);
        
        // Personalizar el renderer de la tabla para colorear los botones
        tabla.getColumn("Modificar").setCellRenderer(new ButtonRenderer("Modificar", new Color(0, 120, 215)));
        tabla.getColumn("Eliminar").setCellRenderer(new ButtonRenderer("Eliminar", new Color(200, 50, 50)));
    }
    
    private void cargarActividadesProgramadas() {
        modelo.setRowCount(0);
        
        Object[][] datos = GestionarActividadProgramada.mostrarActividadesProgramadas();
        
        for (Object[] fila : datos) {
            Object[] nuevaFila = new Object[8];
            System.arraycopy(fila, 0, nuevaFila, 0, 6);
            nuevaFila[6] = "Modificar";
            nuevaFila[7] = "Eliminar";
            
            modelo.addRow(nuevaFila);
        }
    }
    
    // Clase para renderizar botones en la tabla
    class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
        
        public ButtonRenderer(String text, Color color) {
            setText(text);
            setBackground(color);
            setForeground(Color.WHITE);
            setOpaque(true);
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        }
        
        @Override
        public java.awt.Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {
            return this;
        }
    }
}