package GUI;

import javax.swing.*;
import controlador.GestionarActividad;
import clases.Actividad;
import java.awt.*;

public class ActividadActualizarGUI extends JDialog {
    private JTextField txtNombre;
    private JTextArea txtDescripcion;
    private JComboBox<String> comboNivel;
    private Actividad actividad;
    private Runnable onActividadActualizada;
    
    public ActividadActualizarGUI(Actividad actividad, Runnable onActividadActualizada) {
        super((JFrame) null, "Editar Actividad", true);
        this.actividad = actividad;
        this.onActividadActualizada = onActividadActualizada;
        iniciarComponentes();
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    private void iniciarComponentes() {
        setLayout(new GridLayout(4, 2, 10, 10));
        
        // Crear componentes
        txtNombre = new JTextField(actividad.getNombre());
        txtDescripcion = new JTextArea(actividad.getDescripcion(), 3, 20);
        txtDescripcion.setLineWrap(true);
        JScrollPane scrollDescripcion = new JScrollPane(txtDescripcion);
        comboNivel = new JComboBox<>(new String[]{"iniciacion", "medio", "avanzado"});
        comboNivel.setSelectedItem(actividad.getNivel());
        
       
        add(new JLabel("Nombre:"));
        add(txtNombre);
        
        add(new JLabel("Descripción:"));
        add(scrollDescripcion);
        
        add(new JLabel("Nivel:"));
        add(comboNivel);
        
        // Botones
        JButton btnAceptar = new JButton("Aceptar");
        JButton btnCancelar = new JButton("Cancelar");
        
        btnAceptar.addActionListener(e -> {
            if (actualizarActividad()) {
                dispose();
            }
        });
        
        btnCancelar.addActionListener(e -> dispose());
        
        add(btnAceptar);
        add(btnCancelar);
        
        setSize(450, 300);
        setResizable(false);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }
    
    private boolean actualizarActividad() {
        if (txtNombre.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        actividad.setNombre(txtNombre.getText().trim());
        actividad.setDescripcion(txtDescripcion.getText().trim());
        actividad.setNivel((String) comboNivel.getSelectedItem());
        
        boolean actualizado = GestionarActividad.actualizarActividad(actividad);
        
        if (actualizado) {
            JOptionPane.showMessageDialog(this, "Actividad actualizada correctamente", 
                                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
            if (onActividadActualizada != null) {
                onActividadActualizada.run();
            }
            return true;
        } else {
            JOptionPane.showMessageDialog(this, "Error al actualizar la actividad", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}