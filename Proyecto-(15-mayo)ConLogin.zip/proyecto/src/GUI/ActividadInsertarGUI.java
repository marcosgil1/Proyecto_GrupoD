package GUI;

import javax.swing.*;
import controlador.GestionarActividad;
import clases.Actividad;
import java.awt.*;

public class ActividadInsertarGUI extends JDialog {
    private JTextField txtNombre;
    private JTextArea txtDescripcion;
    private JComboBox<String> comboNivel;
    private Runnable onActividadCreada;
    
    public ActividadInsertarGUI(JFrame parent, Runnable onActividadCreada) {
        super(parent, "Nueva Actividad", true);
        this.onActividadCreada = onActividadCreada;
        iniciarComponentes();
        setLocationRelativeTo(parent);
        setVisible(true);
    }
    
    private void iniciarComponentes() {
        setLayout(new GridLayout(4, 2, 10, 10));
        
        // Crear componentes
        txtNombre = new JTextField();
        txtDescripcion = new JTextArea(3, 20);
        txtDescripcion.setLineWrap(true);
        JScrollPane scrollDescripcion = new JScrollPane(txtDescripcion);
        comboNivel = new JComboBox<>(new String[]{"iniciacion", "medio", "avanzado"});
        
       
        add(new JLabel("Nombre:"));
        add(txtNombre);
        
        add(new JLabel("Descripción:"));
        add(scrollDescripcion);
        
        add(new JLabel("Nivel:"));
        add(comboNivel);
        
        // Botones
        JButton btnAceptar = new JButton("Aceptar");
        JButton btnCancelar = new JButton("Cancelar");
        
        btnAceptar.addActionListener(e -> {
            if (guardarActividad()) {
                dispose();
            }
        });
        
        btnCancelar.addActionListener(e -> dispose());
        
        add(btnAceptar);
        add(btnCancelar);
        
        setSize(450, 300);
        setResizable(false);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }
    
    private boolean guardarActividad() {
        if (txtNombre.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        Actividad nueva = new Actividad(0, txtNombre.getText().trim(), 
                        txtDescripcion.getText().trim(), (String) comboNivel.getSelectedItem());
        boolean insertado = GestionarActividad.insertarActividad(nueva);
        
        if (insertado) {
            JOptionPane.showMessageDialog(this, "Actividad creada correctamente", 
                                        "Éxito", JOptionPane.INFORMATION_MESSAGE);
            if (onActividadCreada != null) {
                onActividadCreada.run();
            }
            return true;
        } else {
            JOptionPane.showMessageDialog(this, "Error al crear la actividad", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}