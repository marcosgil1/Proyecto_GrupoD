package controlador;

import DAO.LoginDAO;

public class GestionarLogin {

	public static String iniciarSesion(String usuario, String contrasena) {
		
		return LoginDAO.iniciarSesion(usuario, contrasena);
		
	}

}
