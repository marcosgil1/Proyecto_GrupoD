package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDAO {

    public static String iniciarSesion(String usuario, String contrasena) {

        try {

            Connection conn = Conexion.obtenerConexion();

            // 1. Buscar usuario correcto
            String sql = "SELECT dni FROM usuario WHERE dni = ? AND contrasena = ?";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, usuario);
            ps.setString(2, contrasena);

            ResultSet rs = ps.executeQuery();

            // si no existe usuario
            if (!rs.next()) {
                return null;
            }

            String dni = rs.getString("dni");

            rs.close();
            ps.close();

            // 2. comprobar rol usando DNI
            if (existe(conn, "administrador", dni)) return "ADMIN";
            if (existe(conn, "recepcionista", dni)) return "RECEPCIONISTA";
            if (existe(conn, "entrenador", dni)) return "ENTRENADOR";
            if (existe(conn, "socio", dni)) return "SOCIO";

            return "USUARIO";

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    
    private static boolean existe(Connection con, String tabla, String dni) throws SQLException {

        String sql = "SELECT 1 FROM " + tabla + " WHERE dni_usuario = ?";

        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, dni);

        ResultSet rs = ps.executeQuery();

        boolean ok = rs.next();

        rs.close();
        ps.close();

        return ok;
    }
}