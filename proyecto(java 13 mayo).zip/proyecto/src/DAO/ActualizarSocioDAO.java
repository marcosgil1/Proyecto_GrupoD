package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class ActualizarSocioDAO {

	public static boolean actualizarSocio(String dni, String nombre, String apellidos, String telefono, String email,
			String fechaAlta, String estado, String contrasena) {

		try {

			Connection con = Conexion.obtenerConexion();

			String sql = "SELECT u.dni, u.nombre, u.apellidos, u.telefono, " +
		            "u.email, u.fecha_alta, u.estado, u.contrasena " +
		            "FROM usuario u " +
		            "INNER JOIN socio r ON u.dni = r.dni_usuario";
			PreparedStatement ps = con.prepareStatement(sql);

			ps.setString(1, nombre);
			ps.setString(2, apellidos);
			ps.setString(3, telefono);
			ps.setString(4, email);
			ps.setString(5, fechaAlta);
			ps.setString(6, estado);
			ps.setString(7, contrasena);
			ps.setString(8, dni);

			int filasAfectadas = ps.executeUpdate();

			ps.close();
			con.close();

			return filasAfectadas > 0;

		} catch (Exception e) {

			e.printStackTrace();
			return false;
		}
	}
}