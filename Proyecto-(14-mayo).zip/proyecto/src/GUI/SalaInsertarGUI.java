package GUI;

import javax.swing.*;
import controlador.GestionarSala;
import clases.Sala;
import java.awt.*;

public class SalaInsertarGUI extends JDialog {
    private JTextField txtNombre;
    private JTextField txtMetros;
    private JTextField txtAforo;
    private Runnable onSalaCreada;
    
    public SalaInsertarGUI(JFrame parent, Runnable onSalaCreada) {
        super(parent, "Nueva Sala", true);
        this.onSalaCreada = onSalaCreada;
        iniciarComponentes();
        setLocationRelativeTo(parent);
        setVisible(true);
    }
    
    private void iniciarComponentes() {
        setLayout(new GridLayout(4, 2, 10, 10));
        
        // Crear componentes
        txtNombre = new JTextField();
        txtMetros = new JTextField();
        txtAforo = new JTextField();
        
        // Añadir componentes al GridLayout
        add(new JLabel("Nombre:"));
        add(txtNombre);
        
        add(new JLabel("Metros cuadrados:"));
        add(txtMetros);
        
        add(new JLabel("Aforo máximo:"));
        add(txtAforo);
        
        // Botones
        JButton btnAceptar = new JButton("Aceptar");
        JButton btnCancelar = new JButton("Cancelar");
        
        btnAceptar.addActionListener(e -> {
            if (guardarSala()) {
                dispose();
            }
        });
        
        btnCancelar.addActionListener(e -> dispose());
        
        add(btnAceptar);
        add(btnCancelar);
        
        setSize(450, 250);
        setResizable(false);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }
    
    private boolean guardarSala() {
        if (txtNombre.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            double metros = Double.parseDouble(txtMetros.getText().trim());
            int aforo = Integer.parseInt(txtAforo.getText().trim());
            
            if (metros <= 0 || aforo <= 0) {
                JOptionPane.showMessageDialog(this, "Metros y aforo deben ser mayores que 0", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
            Sala nueva = new Sala(0, txtNombre.getText().trim(), metros, aforo);
            boolean insertado = GestionarSala.insertarSala(nueva);
            
            if (insertado) {
                JOptionPane.showMessageDialog(this, "Sala creada correctamente", 
                                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                if (onSalaCreada != null) {
                    onSalaCreada.run();
                }
                return true;
            } else {
                JOptionPane.showMessageDialog(this, "Error al crear la sala", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Metros y aforo deben ser números válidos", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}