package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import controlador.GestionarActividad;
import clases.Actividad;

public class ActividadLeerGUI extends JFrame {

    private JTable tabla;
    private DefaultTableModel modelo;

    public ActividadLeerGUI() {
        setTitle("Listado de Actividades");
        setSize(900, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        iniciarTabla();
        cargarActividades();
        
        setVisible(true);
    }

    private void iniciarTabla() {
        modelo = new DefaultTableModel();
        
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Descripción");
        modelo.addColumn("Nivel");
        modelo.addColumn("Modificar");
        modelo.addColumn("Eliminar");
        
        tabla = new JTable(modelo);
        
        tabla.getColumnModel().getColumn(4).setPreferredWidth(100);
        tabla.getColumnModel().getColumn(5).setPreferredWidth(100);
        
        tabla.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila = tabla.rowAtPoint(e.getPoint());
                int columna = tabla.columnAtPoint(e.getPoint());
                
                if (columna == 4) { // Botón Modificar
                    int id = Integer.parseInt(tabla.getValueAt(fila, 0).toString());
                    String nombre = tabla.getValueAt(fila, 1).toString();
                    String descripcion = tabla.getValueAt(fila, 2).toString();
                    String nivel = tabla.getValueAt(fila, 3).toString();
                    
                    Actividad actividad = new Actividad(id, nombre, descripcion, nivel);
                    new ActividadActualizarGUI(actividad, () -> cargarActividades());
                    
                } else if (columna == 5) { // Botón Eliminar
                    int id = Integer.parseInt(tabla.getValueAt(fila, 0).toString());
                    String nombre = tabla.getValueAt(fila, 1).toString();
                    
                    int confirm = JOptionPane.showConfirmDialog(null,
                            "¿Estás seguro de que quieres eliminar la actividad: " + nombre + "?",
                            "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
                    
                    if (confirm == JOptionPane.YES_OPTION) {
                        boolean eliminado = GestionarActividad.eliminarActividad(id);
                        
                        if (eliminado) {
                            JOptionPane.showMessageDialog(null, "Actividad eliminada correctamente");
                            cargarActividades();
                        } else {
                            JOptionPane.showMessageDialog(null, "Error: No se puede eliminar la actividad porque tiene programaciones asociadas");
                        }
                    }
                }
            }
        });
        
        JScrollPane scroll = new JScrollPane(tabla);
        
        // Botones
        JButton btnInsertar = new JButton("+ Nueva Actividad");
        btnInsertar.addActionListener(e -> new ActividadInsertarGUI(this, () -> cargarActividades()));
        
        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.addActionListener(e -> cargarActividades());
        
        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(e -> dispose());
        
        JPanel panelSuperior = new JPanel();
        panelSuperior.add(btnInsertar);
        panelSuperior.add(btnActualizar);
        panelSuperior.add(btnVolver);
        
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panelSuperior, BorderLayout.NORTH);
        getContentPane().add(scroll, BorderLayout.CENTER);
        
        // Personalizar el renderer de la tabla para colorear los botones
        tabla.getColumn("Modificar").setCellRenderer(new ButtonRenderer("Modificar", new Color(0, 120, 215)));
        tabla.getColumn("Eliminar").setCellRenderer(new ButtonRenderer("Eliminar", new Color(200, 50, 50)));
    }
    
    private void cargarActividades() {
        modelo.setRowCount(0);
        
        Object[][] datos = GestionarActividad.mostrarActividades();
        
        for (Object[] fila : datos) {
            Object[] nuevaFila = new Object[6];
            
            nuevaFila[0] = fila[0]; // ID
            nuevaFila[1] = fila[1]; // Nombre
            nuevaFila[2] = fila[2]; // Descripción
            nuevaFila[3] = fila[3]; // Nivel
            
            nuevaFila[4] = "Modificar";
            nuevaFila[5] = "Eliminar";
            
            modelo.addRow(nuevaFila);
        }
    }
    
    // Clase para renderizar botones en la tabla
    class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
        
        public ButtonRenderer(String text, Color color) {
            setText(text);
            setBackground(color);
            setForeground(Color.WHITE);
            setOpaque(true);
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        }
        
        @Override
        public java.awt.Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {
            return this;
        }
    }
}