package GUI;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;

public class UsuarioElegirVerGUI extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UsuarioElegirVerGUI frame = new UsuarioElegirVerGUI();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public UsuarioElegirVerGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		
		JButton btnVerSocios = new JButton("Ver Socios");
		btnVerSocios.setBounds(157, 59, 165, 27);
		btnVerSocios.addActionListener(e -> new SocioLeerGUI());
		contentPane.add(btnVerSocios);
		
		JButton btnVerEntrenadores = new JButton("Ver Entrenadores");
		btnVerEntrenadores.setBounds(157, 98, 165, 27);
		btnVerEntrenadores.addActionListener(e -> new EntrenadorLeerGUI().setVisible(true));
		contentPane.add(btnVerEntrenadores);		
		
		
		JButton btnVerRecepcionistas = new JButton("Ver Recepcionistas");
		btnVerRecepcionistas.setBounds(157, 142, 165, 27);
		btnVerRecepcionistas.addActionListener(e -> new RecepcionistaLeerGUI().setVisible(true));
		contentPane.add(btnVerRecepcionistas);
		
		JButton btnVerAdministradores = new JButton("Ver Administradores");
		btnVerAdministradores.setBounds(157, 181, 165, 27);
		btnVerAdministradores.addActionListener(e -> new AdministradorLeerGUI().setVisible(true));
		contentPane.add(btnVerAdministradores);
		
		
		JButton btnVolver = new JButton("Volver");
		btnVolver.setBounds(12, 59, 105, 27);
		btnVolver.addActionListener(e -> dispose());
		
		contentPane.add(btnVolver);

	}
}
