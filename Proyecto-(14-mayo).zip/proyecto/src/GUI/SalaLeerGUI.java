package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import controlador.GestionarSala;
import clases.Sala;

public class SalaLeerGUI extends JFrame {

    private JTable tabla;
    private DefaultTableModel modelo;

    public SalaLeerGUI() {
        setTitle("Listado de Salas");
        setSize(900, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        iniciarTabla();
        cargarSalas();
        
        setVisible(true);
    }

    private void iniciarTabla() {
        modelo = new DefaultTableModel();
        
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Metros²");
        modelo.addColumn("Aforo Máx");
        modelo.addColumn("Modificar");
        modelo.addColumn("Eliminar");
        
        tabla = new JTable(modelo);
        
        tabla.getColumnModel().getColumn(4).setPreferredWidth(100);
        tabla.getColumnModel().getColumn(5).setPreferredWidth(100);
        
        tabla.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila = tabla.rowAtPoint(e.getPoint());
                int columna = tabla.columnAtPoint(e.getPoint());
                
                if (fila >= 0) {
                    if (columna == 4) { // Botón Modificar
                        int id = Integer.parseInt(tabla.getValueAt(fila, 0).toString());
                        String nombre = tabla.getValueAt(fila, 1).toString();
                        double metros = Double.parseDouble(tabla.getValueAt(fila, 2).toString());
                        int aforo = Integer.parseInt(tabla.getValueAt(fila, 3).toString());
                        
                        Sala sala = new Sala(id, nombre, metros, aforo);
                        new SalaActualizarGUI(sala, () -> cargarSalas());
                        
                    } else if (columna == 5) { // Botón Eliminar
                        int id = Integer.parseInt(tabla.getValueAt(fila, 0).toString());
                        String nombre = tabla.getValueAt(fila, 1).toString();
                        
                        int confirm = JOptionPane.showConfirmDialog(SalaLeerGUI.this,
                                "¿Estás seguro de que quieres eliminar la sala: " + nombre + "?",
                                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
                        
                        if (confirm == JOptionPane.YES_OPTION) {
                            boolean eliminado = GestionarSala.eliminarSala(id);
                            
                            if (eliminado) {
                                JOptionPane.showMessageDialog(SalaLeerGUI.this, "Sala eliminada correctamente");
                                cargarSalas();
                            } else {
                                JOptionPane.showMessageDialog(SalaLeerGUI.this,
                                        "Error: No se puede eliminar la sala porque tiene maquinaria o actividades asociadas",
                                        "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }
                }
            }
        });
        
        JScrollPane scroll = new JScrollPane(tabla);
        
        // Botones
        JButton btnInsertar = new JButton("+ Nueva Sala");
        btnInsertar.addActionListener(e -> new SalaInsertarGUI(this, () -> cargarSalas()));
        
        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.addActionListener(e -> cargarSalas());
        
        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(e -> dispose());
        
        JPanel panelSuperior = new JPanel();
        panelSuperior.add(btnInsertar);
        panelSuperior.add(btnActualizar);
        panelSuperior.add(btnVolver);
        
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panelSuperior, BorderLayout.NORTH);
        getContentPane().add(scroll, BorderLayout.CENTER);
        
        // Personalizar el renderer de la tabla para colorear los botones
        tabla.getColumn("Modificar").setCellRenderer(new ButtonRenderer("Modificar", new Color(0, 120, 215)));
        tabla.getColumn("Eliminar").setCellRenderer(new ButtonRenderer("Eliminar", new Color(200, 50, 50)));
    }
    
    private void cargarSalas() {
        modelo.setRowCount(0);
        
        Object[][] datos = GestionarSala.mostrarSalas();
        
        for (Object[] fila : datos) {
            Object[] nuevaFila = new Object[6];
            
            nuevaFila[0] = fila[0]; // ID
            nuevaFila[1] = fila[1]; // Nombre
            nuevaFila[2] = fila[2]; // Metros²
            nuevaFila[3] = fila[3]; // Aforo Máx
            
            nuevaFila[4] = "Modificar";
            nuevaFila[5] = "Eliminar";
            
            modelo.addRow(nuevaFila);
        }
    }
    
    // Clase para renderizar botones en la tabla
    class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
        
        public ButtonRenderer(String text, Color color) {
            setText(text);
            setBackground(color);
            setForeground(Color.WHITE);
            setOpaque(true);
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        }
        
        @Override
        public java.awt.Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {
            return this;
        }
    }
}