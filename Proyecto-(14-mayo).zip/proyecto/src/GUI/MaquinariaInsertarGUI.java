package GUI;

import javax.swing.*;
import controlador.GestionarMaquinaria;
import clases.Maquinaria;
import java.awt.*;
import java.time.LocalDate;

public class MaquinariaInsertarGUI extends JDialog {
    private JTextField txtTipo;
    private JTextField txtMarca;
    private JTextField txtNSerie;
    private JComboBox<String> comboEstado;
    private JTextField txtFechaCompra;
    private JTextField txtFechaMantenimiento;
    private JComboBox<String> comboSala;
    private Runnable onMaquinariaCreada;
    
    public MaquinariaInsertarGUI(JFrame parent, Runnable onMaquinariaCreada) {
        super(parent, "Nueva Maquinaria", true);
        this.onMaquinariaCreada = onMaquinariaCreada;
        iniciarComponentes();
        setLocationRelativeTo(parent);
        setVisible(true);
    }
    
    private void iniciarComponentes() {
        setLayout(new GridLayout(8, 2, 10, 10));
        
        // Crear componentes
        txtTipo = new JTextField();
        txtMarca = new JTextField();
        txtNSerie = new JTextField();
        comboEstado = new JComboBox<>(new String[]{"operativa", "averiada", "mantenimiento"});
        txtFechaCompra = new JTextField(LocalDate.now().toString());
        txtFechaMantenimiento = new JTextField(LocalDate.now().toString());
        
        // Cargar salas para el combo
        Object[][] salas = GestionarMaquinaria.obtenerSalasParaCombo();
        comboSala = new JComboBox<>();
        for (Object[] sala : salas) {
            comboSala.addItem(sala[0] + " - " + sala[1]);
        }
        
        // Añadir componentes al GridLayout
        add(new JLabel("Tipo:"));
        add(txtTipo);
        
        add(new JLabel("Marca:"));
        add(txtMarca);
        
        add(new JLabel("Nº Serie:"));
        add(txtNSerie);
        
        add(new JLabel("Estado:"));
        add(comboEstado);
        
        add(new JLabel("Fecha Compra (YYYY-MM-DD):"));
        add(txtFechaCompra);
        
        add(new JLabel("Fecha Últ. Mantenimiento:"));
        add(txtFechaMantenimiento);
        
        add(new JLabel("Sala:"));
        add(comboSala);
        
        // Botones
        JButton btnAceptar = new JButton("Aceptar");
        JButton btnCancelar = new JButton("Cancelar");
        
        btnAceptar.addActionListener(e -> {
            if (guardarMaquinaria()) {
                dispose();
            }
        });
        
        btnCancelar.addActionListener(e -> dispose());
        
        add(btnAceptar);
        add(btnCancelar);
        
        setSize(500, 400);
        setResizable(false);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }
    
    private boolean guardarMaquinaria() {
        if (txtTipo.getText().trim().isEmpty() || 
            txtMarca.getText().trim().isEmpty() || 
            txtNSerie.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tipo, Marca y Nº Serie son obligatorios", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            String fechaCompra = txtFechaCompra.getText().trim();
            String fechaMantenimiento = txtFechaMantenimiento.getText().trim();
            
            String salaSeleccionada = (String) comboSala.getSelectedItem();
            int idSala = Integer.parseInt(salaSeleccionada.split(" - ")[0]);
            
            Maquinaria nueva = new Maquinaria(0, txtTipo.getText().trim(), 
                    txtMarca.getText().trim(), txtNSerie.getText().trim(),
                    (String) comboEstado.getSelectedItem(), fechaCompra, 
                    fechaMantenimiento, idSala);
            
            boolean insertado = GestionarMaquinaria.insertarMaquinaria(nueva);
            
            if (insertado) {
                JOptionPane.showMessageDialog(this, "Maquinaria creada correctamente", 
                                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                if (onMaquinariaCreada != null) {
                    onMaquinariaCreada.run();
                }
                return true;
            } else {
                JOptionPane.showMessageDialog(this, "Error al crear la maquinaria", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Error en los datos ingresados", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}