package GUI;

import javax.swing.*;
import controlador.GestionarMaquinaria;
import clases.Maquinaria;
import java.awt.*;

public class MaquinariaActualizarGUI extends JDialog {
    private JTextField txtTipo;
    private JTextField txtMarca;
    private JTextField txtNSerie;
    private JComboBox<String> comboEstado;
    private JTextField txtFechaCompra;
    private JTextField txtFechaMantenimiento;
    private JComboBox<String> comboSala;
    private Maquinaria maquinaria;
    private Runnable onMaquinariaActualizada;
    
    public MaquinariaActualizarGUI(Maquinaria maquinaria, Runnable onMaquinariaActualizada) {
        super((JFrame) null, "Editar Maquinaria", true);
        this.maquinaria = maquinaria;
        this.onMaquinariaActualizada = onMaquinariaActualizada;
        iniciarComponentes();
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    private void iniciarComponentes() {
        setLayout(new GridLayout(8, 2, 10, 10));
        
        // Crear componentes con valores actuales
        txtTipo = new JTextField(maquinaria.getTipo());
        txtMarca = new JTextField(maquinaria.getMarca());
        txtNSerie = new JTextField(maquinaria.getnSerie());
        comboEstado = new JComboBox<>(new String[]{"operativa", "averiada", "mantenimiento"});
        comboEstado.setSelectedItem(maquinaria.getEstado());
        txtFechaCompra = new JTextField(maquinaria.getFechaCompra());
        txtFechaMantenimiento = new JTextField(maquinaria.getFechaUltimoMantenimiento());
        
        // Cargar salas para el combo
        Object[][] salas = GestionarMaquinaria.obtenerSalasParaCombo();
        comboSala = new JComboBox<>();
        int salaIndex = 0;
        for (int i = 0; i < salas.length; i++) {
            comboSala.addItem(salas[i][0] + " - " + salas[i][1]);
            if (Integer.parseInt(salas[i][0].toString()) == maquinaria.getIdSala()) {
                salaIndex = i;
            }
        }
        comboSala.setSelectedIndex(salaIndex);
        
        // Añadir componentes al GridLayout
        add(new JLabel("Tipo:"));
        add(txtTipo);
        
        add(new JLabel("Marca:"));
        add(txtMarca);
        
        add(new JLabel("Nº Serie:"));
        add(txtNSerie);
        
        add(new JLabel("Estado:"));
        add(comboEstado);
        
        add(new JLabel("Fecha Compra:"));
        add(txtFechaCompra);
        
        add(new JLabel("Fecha Últ. Mantenimiento:"));
        add(txtFechaMantenimiento);
        
        add(new JLabel("Sala:"));
        add(comboSala);
        
        // Botones
        JButton btnAceptar = new JButton("Aceptar");
        JButton btnCancelar = new JButton("Cancelar");
        
        btnAceptar.addActionListener(e -> {
            if (actualizarMaquinaria()) {
                dispose();
            }
        });
        
        btnCancelar.addActionListener(e -> dispose());
        
        add(btnAceptar);
        add(btnCancelar);
        
        setSize(500, 400);
        setResizable(false);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }
    
    private boolean actualizarMaquinaria() {
        if (txtTipo.getText().trim().isEmpty() || 
            txtMarca.getText().trim().isEmpty() || 
            txtNSerie.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Tipo, Marca y Nº Serie son obligatorios", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            String salaSeleccionada = (String) comboSala.getSelectedItem();
            int idSala = Integer.parseInt(salaSeleccionada.split(" - ")[0]);
            
            maquinaria.setTipo(txtTipo.getText().trim());
            maquinaria.setMarca(txtMarca.getText().trim());
            maquinaria.setnSerie(txtNSerie.getText().trim());
            maquinaria.setEstado((String) comboEstado.getSelectedItem());
            maquinaria.setFechaCompra(txtFechaCompra.getText().trim());
            maquinaria.setFechaUltimoMantenimiento(txtFechaMantenimiento.getText().trim());
            maquinaria.setIdSala(idSala);
            
            boolean actualizado = GestionarMaquinaria.actualizarMaquinaria(maquinaria);
            
            if (actualizado) {
                JOptionPane.showMessageDialog(this, "Maquinaria actualizada correctamente", 
                                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                if (onMaquinariaActualizada != null) {
                    onMaquinariaActualizada.run();
                }
                return true;
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar la maquinaria", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Error en los datos ingresados", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}