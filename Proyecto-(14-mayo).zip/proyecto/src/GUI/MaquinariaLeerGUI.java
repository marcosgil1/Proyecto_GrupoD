package GUI;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import controlador.GestionarMaquinaria;
import clases.Maquinaria;

public class MaquinariaLeerGUI extends JFrame {

    private JTable tabla;
    private DefaultTableModel modelo;

    public MaquinariaLeerGUI() {
        setTitle("Listado de Maquinaria");
        setSize(1200, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        
        iniciarTabla();
        cargarMaquinaria();
        
        setVisible(true);
    }

    private void iniciarTabla() {
        modelo = new DefaultTableModel();
        
        modelo.addColumn("ID");
        modelo.addColumn("Tipo");
        modelo.addColumn("Marca");
        modelo.addColumn("Nº Serie");
        modelo.addColumn("Estado");
        modelo.addColumn("Fecha Compra");
        modelo.addColumn("Últ. Mantenimiento");
        modelo.addColumn("Sala");
        modelo.addColumn("Modificar");
        modelo.addColumn("Eliminar");
        
        tabla = new JTable(modelo);
        tabla.setFont(new Font("Arial", Font.PLAIN, 11));
        
        tabla.getColumnModel().getColumn(8).setPreferredWidth(100);
        tabla.getColumnModel().getColumn(9).setPreferredWidth(100);
        
        tabla.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int fila = tabla.rowAtPoint(e.getPoint());
                int columna = tabla.columnAtPoint(e.getPoint());
                
                if (fila >= 0) {
                    if (columna == 8) { // Botón Modificar
                        int id = Integer.parseInt(tabla.getValueAt(fila, 0).toString());
                        Maquinaria maquinaria = GestionarMaquinaria.obtenerMaquinariaPorId(id);
                        if (maquinaria != null) {
                            new MaquinariaActualizarGUI(maquinaria, () -> cargarMaquinaria());
                        }
                        
                    } else if (columna == 9) { // Botón Eliminar
                        int id = Integer.parseInt(tabla.getValueAt(fila, 0).toString());
                        String tipo = tabla.getValueAt(fila, 1).toString();
                        
                        int confirm = JOptionPane.showConfirmDialog(MaquinariaLeerGUI.this,
                                "¿Estás seguro de que quieres eliminar la maquinaria: " + tipo + "?",
                                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
                        
                        if (confirm == JOptionPane.YES_OPTION) {
                            boolean eliminado = GestionarMaquinaria.eliminarMaquinaria(id);
                            
                            if (eliminado) {
                                JOptionPane.showMessageDialog(MaquinariaLeerGUI.this, 
                                                            "Maquinaria eliminada correctamente");
                                cargarMaquinaria();
                            } else {
                                JOptionPane.showMessageDialog(MaquinariaLeerGUI.this, 
                                                            "Error al eliminar la maquinaria",
                                                            "Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }
                }
            }
        });
        
        JScrollPane scroll = new JScrollPane(tabla);
        
        // Botones
        JButton btnInsertar = new JButton("+ Nueva Maquinaria");
        btnInsertar.addActionListener(e -> new MaquinariaInsertarGUI(this, () -> cargarMaquinaria()));
        
        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.addActionListener(e -> cargarMaquinaria());
        
        JButton btnVolver = new JButton("Volver");
        btnVolver.addActionListener(e -> dispose());
        
        JPanel panelSuperior = new JPanel();
        panelSuperior.add(btnInsertar);
        panelSuperior.add(btnActualizar);
        panelSuperior.add(btnVolver);
        
        getContentPane().setLayout(new BorderLayout());
        getContentPane().add(panelSuperior, BorderLayout.NORTH);
        getContentPane().add(scroll, BorderLayout.CENTER);
        
        // Personalizar el renderer de la tabla para colorear los botones
        tabla.getColumn("Modificar").setCellRenderer(new ButtonRenderer("Modificar", new Color(0, 120, 215)));
        tabla.getColumn("Eliminar").setCellRenderer(new ButtonRenderer("Eliminar", new Color(200, 50, 50)));
    }
    
    private void cargarMaquinaria() {
        modelo.setRowCount(0);
        
        Object[][] datos = GestionarMaquinaria.mostrarMaquinaria();
        
        for (Object[] fila : datos) {
            Object[] nuevaFila = new Object[10];
            
            nuevaFila[0] = fila[0]; // ID
            nuevaFila[1] = fila[1]; // Tipo
            nuevaFila[2] = fila[2]; // Marca
            nuevaFila[3] = fila[3]; // Nº Serie
            nuevaFila[4] = fila[4]; // Estado
            nuevaFila[5] = fila[5]; // Fecha Compra
            nuevaFila[6] = fila[6]; // Últ. Mantenimiento
            nuevaFila[7] = fila[7]; // Sala
            
            nuevaFila[8] = "Modificar";
            nuevaFila[9] = "Eliminar";
            
            modelo.addRow(nuevaFila);
        }
    }
    
    // Clase para renderizar botones en la tabla
    class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
        
        public ButtonRenderer(String text, Color color) {
            setText(text);
            setBackground(color);
            setForeground(Color.WHITE);
            setOpaque(true);
            setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10));
        }
        
        @Override
        public java.awt.Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                boolean hasFocus, int row, int column) {
            return this;
        }
    }
}