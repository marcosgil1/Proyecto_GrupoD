package GUI;

import javax.swing.*;
import controlador.GestionarSala;
import clases.Sala;
import java.awt.*;

public class SalaActualizarGUI extends JDialog {
    private JTextField txtNombre;
    private JTextField txtMetros;
    private JTextField txtAforo;
    private Sala sala;
    private Runnable onSalaActualizada;
    
    public SalaActualizarGUI(Sala sala, Runnable onSalaActualizada) {
        super((JFrame) null, "Editar Sala", true);
        this.sala = sala;
        this.onSalaActualizada = onSalaActualizada;
        iniciarComponentes();
        setLocationRelativeTo(null);
        setVisible(true);
    }
    
    private void iniciarComponentes() {
        setLayout(new BorderLayout(10, 10));
        
        // Panel del formulario
        JPanel formulario = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Crear componentes con los valores actuales
        txtNombre = new JTextField(sala.getNombre(), 20);
        txtMetros = new JTextField(String.valueOf(sala.getMetrosCuadrados()), 20);
        txtAforo = new JTextField(String.valueOf(sala.getAforoMax()), 20);
        
        // Añadir componentes al formulario
        gbc.gridx = 0;
        gbc.gridy = 0;
        formulario.add(new JLabel("Nombre:"), gbc);
        gbc.gridx = 1;
        formulario.add(txtNombre, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        formulario.add(new JLabel("Metros cuadrados:"), gbc);
        gbc.gridx = 1;
        formulario.add(txtMetros, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 2;
        formulario.add(new JLabel("Aforo máximo:"), gbc);
        gbc.gridx = 1;
        formulario.add(txtAforo, gbc);
        
        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        JButton btnAceptar = new JButton("Aceptar");
        JButton btnCancelar = new JButton("Cancelar");
        
        btnAceptar.addActionListener(e -> {
            if (actualizarSala()) {
                dispose();
            }
        });
        
        btnCancelar.addActionListener(e -> dispose());
        
        panelBotones.add(btnAceptar);
        panelBotones.add(btnCancelar);
        
        // Añadir paneles al diálogo
        add(formulario, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
        
        // Configurar tamaño del diálogo
        setSize(450, 250);
        setResizable(false);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
    }
    
    private boolean actualizarSala() {
        if (txtNombre.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "El nombre es obligatorio", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        
        try {
            double metros = Double.parseDouble(txtMetros.getText().trim());
            int aforo = Integer.parseInt(txtAforo.getText().trim());
            
            if (metros <= 0 || aforo <= 0) {
                JOptionPane.showMessageDialog(this, "Metros y aforo deben ser mayores que 0", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
            sala.setNombre(txtNombre.getText().trim());
            sala.setMetrosCuadrados(metros);
            sala.setAforoMax(aforo);
            
            boolean actualizado = GestionarSala.actualizarSala(sala);
            
            if (actualizado) {
                JOptionPane.showMessageDialog(this, "Sala actualizada correctamente", 
                                            "Éxito", JOptionPane.INFORMATION_MESSAGE);
                if (onSalaActualizada != null) {
                    onSalaActualizada.run();
                }
                return true;
            } else {
                JOptionPane.showMessageDialog(this, "Error al actualizar la sala", 
                                            "Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
            
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Metros y aforo deben ser números válidos", 
                                        "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }
    }
}