package controlador;

import DAO.UsuarioDAO;
import clases.*;

public class GestionarUsuarios {
	
	// ==================== INSERTAR ====================
	
	public static boolean insertarSocioFull(SocioFull s) {
		return UsuarioDAO.insertarSocioFull(s);
	}
	
	public static boolean insertarSocioFlexible(SocioFlexible s) {
		return UsuarioDAO.insertarSocioFlexible(s);
	}
	
	public static boolean insertarEntrenador(Entrenador e) {
		return UsuarioDAO.insertarEntrenador(e);
	}
	
	public static boolean insertarAdministrador(Administrador a) {
		return UsuarioDAO.insertarUsuarioBasico(a, "administrador");
	}
	
	public static boolean insertarRecepcionista(Recepcionista r) {
		return UsuarioDAO.insertarUsuarioBasico(r, "recepcionista");
	}
	
	
	// ==================== ACTUALIZAR ====================
	
	public static boolean actualizarUsuario(String dni, String nombre, String apellidos, String telefono, String email,
			String fechaAlta, String estado, String contrasena) {
		return UsuarioDAO.actualizarUsuario(dni, nombre, apellidos, telefono, email, fechaAlta, estado, contrasena);
	}
	
	public static boolean actualizarSocio(String dni, String nombre, String apellidos, String telefono, String email,
			String fechaAlta, String estado, String contrasena) {
		return UsuarioDAO.actualizarUsuario(dni, nombre, apellidos, telefono, email, fechaAlta, estado, contrasena);
	}
	
	
	// ==================== ELIMINAR ====================
	
	public static boolean eliminarUsuario(Usuario u) {
		return UsuarioDAO.eliminarUsuarioBD(u);
	}
	
	public static boolean eliminarAdministrador(Administrador a) {
		return UsuarioDAO.eliminarUsuarioBD(a);
	}
	
	public static boolean eliminarSocio(Socio s) {
		return UsuarioDAO.eliminarUsuarioBD(s);
	}
	
	public static boolean eliminarRecepcionista(Recepcionista r) {
		return UsuarioDAO.eliminarUsuarioBD(r);
	}
	
	public static boolean eliminarEntrenador(Entrenador e) {
		return UsuarioDAO.eliminarUsuarioBD(e);
	}
	
	
	// ==================== MOSTRAR ====================
	
	public static Object[][] mostrarUsuarios() {
		return UsuarioDAO.obtenerUsuarios();
	}
	
	public static Object[][] mostrarAdministrador() {
		return UsuarioDAO.obtenerAdministrador();
	}
	
	public static Object[][] mostrarSocio() {
		return UsuarioDAO.obtenerSocios();
	}
	
	public static Object[][] mostrarRecepcionista() {
		return UsuarioDAO.obtenerRecepcionista();
	}
}