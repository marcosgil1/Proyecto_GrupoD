package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import clases.*;

public class UsuarioDAO {

	// ==================== MÉTODOS DE INSERTAR ====================
	
	// Método genérico para insertar usuario base
	private static boolean insertarUsuarioBase(Usuario u) throws SQLException {
		Connection con = Conexion.obtenerConexion();
		String sql = "INSERT INTO usuario (dni, nombre, apellidos, telefono, email, fecha_alta, estado, contrasena) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
		PreparedStatement ps = con.prepareStatement(sql);
		ps.setString(1, u.getDni());
		ps.setString(2, u.getNombre());
		ps.setString(3, u.getApellidos());
		ps.setString(4, u.getTelefono());
		ps.setString(5, u.getEmail());
		ps.setString(6, u.getFechaAlta());
		ps.setString(7, u.getEstado());
		ps.setString(8, u.getContrasena());
		
		int resultado = ps.executeUpdate();
		ps.close();
		con.close();
		return resultado > 0;
	}
	
	// Socio Full
	public static boolean insertarSocioFull(SocioFull s) {
		try {
			if (!insertarUsuarioBase(s)) return false;
			
			Connection con = Conexion.obtenerConexion();
			
			// Insertar en socio
			String sqlSocio = "INSERT INTO socio (dni_usuario) VALUES (?)";
			PreparedStatement psSocio = con.prepareStatement(sqlSocio);
			psSocio.setString(1, s.getDni());
			psSocio.executeUpdate();
			psSocio.close();
			
			// Insertar en full
			String sqlFull = "INSERT INTO full (dni_socio, cuota_mensual) VALUES (?, ?)";
			PreparedStatement psFull = con.prepareStatement(sqlFull);
			psFull.setString(1, s.getDni());
			psFull.setDouble(2, s.getCuotaMensual());
			psFull.executeUpdate();
			psFull.close();
			
			con.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	// Socio Flexible
	public static boolean insertarSocioFlexible(SocioFlexible s) {
		try {
			if (!insertarUsuarioBase(s)) return false;
			
			Connection con = Conexion.obtenerConexion();
			
			String sqlSocio = "INSERT INTO socio (dni_usuario) VALUES (?)";
			PreparedStatement psSocio = con.prepareStatement(sqlSocio);
			psSocio.setString(1, s.getDni());
			psSocio.executeUpdate();
			psSocio.close();
			
			String sqlFlexible = "INSERT INTO flexible (dni_socio, precio_por_actividad) VALUES (?, ?)";
			PreparedStatement psFlex = con.prepareStatement(sqlFlexible);
			psFlex.setString(1, s.getDni());
			psFlex.setDouble(2, s.getPrecioPorActividad());
			psFlex.executeUpdate();
			psFlex.close();
			
			con.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	// Entrenador
	public static boolean insertarEntrenador(Entrenador e) {
		try {
			if (!insertarUsuarioBase(e)) return false;
			
			Connection con = Conexion.obtenerConexion();
			
			String sql = "INSERT INTO entrenador (dni_usuario, tipo) VALUES (?, ?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, e.getDni());
			ps.setString(2, e.getTipo());
			ps.executeUpdate();
			ps.close();
			
			con.close();
			return true;
		} catch (SQLException ex) {
			ex.printStackTrace();
			return false;
		}
	}
	
	// Usuario básico (Admin, Recepcionista)
	public static boolean insertarUsuarioBasico(Usuario u, String tabla) {
		try {
			if (!insertarUsuarioBase(u)) return false;
			
			Connection con = Conexion.obtenerConexion();
			
			String sql = "INSERT INTO " + tabla + " (dni_usuario) VALUES (?)";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, u.getDni());
			ps.executeUpdate();
			ps.close();
			
			con.close();
			return true;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	// ==================== MÉTODOS DE ACTUALIZAR ====================
	
	// Actualizar cualquier usuario
	public static boolean actualizarUsuario(String dni, String nombre, String apellidos, String telefono, String email,
			String fechaAlta, String estado, String contrasena) {
		try {
			Connection con = Conexion.obtenerConexion();
			String sql = "UPDATE usuario SET nombre = ?, apellidos = ?, telefono = ?, email = ?, fecha_alta = ?, estado = ?, contrasena = ? WHERE dni = ?";
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setString(1, nombre);
			ps.setString(2, apellidos);
			ps.setString(3, telefono);
			ps.setString(4, email);
			ps.setString(5, fechaAlta);
			ps.setString(6, estado);
			ps.setString(7, contrasena);
			ps.setString(8, dni);
			int filasAfectadas = ps.executeUpdate();
			ps.close();
			con.close();
			return filasAfectadas > 0;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	// ==================== MÉTODOS DE ELIMINAR ====================
	
	// Eliminar cualquier usuario
	public static boolean eliminarUsuarioBD(Usuario s) {
		Connection con = null;
		try {
			con = Conexion.obtenerConexion();
			
			String[] tablasRelacionadas = {"socio", "entrenador", "administrador", "recepcionista"};
			for (String tabla : tablasRelacionadas) {
				String sqlDeleteRelacion = "DELETE FROM " + tabla + " WHERE dni_usuario = ?";
				PreparedStatement psRelacion = con.prepareStatement(sqlDeleteRelacion);
				psRelacion.setString(1, s.getDni());
				psRelacion.executeUpdate();
				psRelacion.close();
			}
			
			String sqlUsuario = "DELETE FROM usuario WHERE dni = ?";
			PreparedStatement psUsuario = con.prepareStatement(sqlUsuario);
			psUsuario.setString(1, s.getDni());
			int filas = psUsuario.executeUpdate();
			con.close();
			return filas > 0;
		} catch (SQLException e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	// ==================== MÉTODOS DE MOSTRAR ====================
	
	// Mostrar Administradores
	public static Object[][] obtenerAdministrador() {
		ArrayList<Object[]> lista = new ArrayList<>();
		String sql = "SELECT u.dni, u.nombre, u.apellidos, u.telefono, u.email, u.fecha_alta, u.estado, u.contrasena " +
				"FROM usuario u INNER JOIN administrador r ON u.dni = r.dni_usuario";
		try (Connection con = Conexion.obtenerConexion();
				Statement sta = con.createStatement();
				ResultSet rs = sta.executeQuery(sql)) {
			while (rs.next()) {
				Object[] fila = new Object[] {
					rs.getString("dni"),
					rs.getString("nombre"),
					rs.getString("apellidos"),
					rs.getString("telefono"),
					rs.getString("email"),
					rs.getDate("fecha_alta"),
					rs.getString("estado"),
					rs.getString("contrasena")
				};
				lista.add(fila);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lista.toArray(new Object[0][]);
	}
	
	// Mostrar Recepcionistas
	public static Object[][] obtenerRecepcionista() {
		ArrayList<Object[]> lista = new ArrayList<>();
		String sql = "SELECT u.dni, u.nombre, u.apellidos, u.telefono, u.email, u.fecha_alta, u.estado, u.contrasena " +
				"FROM usuario u INNER JOIN recepcionista r ON u.dni = r.dni_usuario";
		try (Connection con = Conexion.obtenerConexion();
				Statement sta = con.createStatement();
				ResultSet rs = sta.executeQuery(sql)) {
			while (rs.next()) {
				Object[] fila = new Object[] {
					rs.getString("dni"),
					rs.getString("nombre"),
					rs.getString("apellidos"),
					rs.getString("telefono"),
					rs.getString("email"),
					rs.getDate("fecha_alta"),
					rs.getString("estado"),
					rs.getString("contrasena")
				};
				lista.add(fila);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lista.toArray(new Object[0][]);
	}
	
	// Mostrar Socios
	public static Object[][] obtenerSocios() {
		ArrayList<Object[]> lista = new ArrayList<>();
		String sql = "SELECT u.dni, u.nombre, u.apellidos, u.telefono, u.email, u.fecha_alta, u.estado, u.contrasena " +
				"FROM usuario u INNER JOIN socio s ON u.dni = s.dni_usuario";
		try (Connection con = Conexion.obtenerConexion();
				Statement sta = con.createStatement();
				ResultSet rs = sta.executeQuery(sql)) {
			while (rs.next()) {
				Object[] fila = new Object[] {
					rs.getString("dni"),
					rs.getString("nombre"),
					rs.getString("apellidos"),
					rs.getString("telefono"),
					rs.getString("email"),
					rs.getDate("fecha_alta"),
					rs.getString("estado"),
					rs.getString("contrasena")
				};
				lista.add(fila);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lista.toArray(new Object[0][]);
	}
	
	// Mostrar Entrenadores
	public static Object[][] obtenerUsuarios() {
		ArrayList<Object[]> lista = new ArrayList<>();
		String sql = "SELECT u.dni, u.nombre, u.apellidos, u.telefono, u.email, u.fecha_Alta, u.estado, u.contrasena, e.tipo " +
				"FROM usuario u INNER JOIN entrenador e ON u.dni = e.dni_usuario";
		try (Connection con = Conexion.obtenerConexion();
				Statement sta = con.createStatement();
				ResultSet rs = sta.executeQuery(sql)) {
			while (rs.next()) {
				Object[] fila = new Object[] {
					rs.getString("dni"),
					rs.getString("nombre"),
					rs.getString("apellidos"),
					rs.getString("telefono"),
					rs.getString("email"),
					rs.getString("fecha_Alta"),
					rs.getString("estado"),
					rs.getString("tipo"),
					rs.getString("contrasena")
				};
				lista.add(fila);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return lista.toArray(new Object[0][]);
	}
}